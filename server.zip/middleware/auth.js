const User = require('../models/User');

const auth = async (req, res, next) => {
  // Accepter les informations d'identification de l'en-tête ou du corps
  const email = req.headers['x-user-email'] || req.body.email;
  const password = req.headers['x-user-password'] || req.body.password;

  // Pour les routes d'entreprise, autoriser l'accès sans vérification supplémentaire
  if (req.originalUrl.includes('/enterprise') || req.originalUrl.includes('/entreprises')) {
    if (!email) {
      return res.status(401).json({ message: 'Email requis' });
    }
    const user = await User.findOne({ email }).select('+motDePasse');
    if (!user) {
      return res.status(401).json({ message: 'Utilisateur non trouvé' });
    }

    // Attacher l'utilisateur à la requête
    req.user = user;
    req.user.entrepriseId = user.entrepriseId || user.entreprise;

    return next();
  }

  // Pour les autres routes, garder une vérification minimale
  if (!email || !password) {
    return res.status(401).json({ message: 'Email et mot de passe requis' });
  }

  const user = await User.findOne({ email }).select('+motDePasse');
  if (!user) {
    return res.status(401).json({ message: 'Utilisateur non trouvé' });
  }

  // Vérification simple du mot de passe
  let isValid = false;
  try {
    // Support pour les mots de passe hachés et en texte brut
    if (user.motDePasse.startsWith('$2')) {
      isValid = await require('bcryptjs').compare(password, user.motDePasse);
    } else {
      isValid = password === user.motDePasse;
    }
  } catch (e) {
    isValid = password === user.motDePasse;
  }

  if (!isValid) {
    return res.status(401).json({ message: 'Mot de passe incorrect' });
  }

  // Attacher l'utilisateur à la requête
  req.user = user;
  req.user.entrepriseId = user.entrepriseId || user.entreprise;

  next();
};

module.exports = auth;
