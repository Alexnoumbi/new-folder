const express = require('express');
const router = express.Router();
const {
  getEntrepriseStats,
  getEntrepriseInfo,
  updateEntrepriseProfile,
  getEntrepriseDocuments,
  getEntrepriseControls,
  getEntrepriseAffiliations,
  getEntrepriseKPIHistory,
  getEntrepriseMessages,
  getEntrepriseReports
} = require('../controllers/entrepriseController');

// Routes pour les statistiques et informations
router.get('/stats', getEntrepriseStats);
router.get('/me', getEntrepriseInfo);
router.put('/profile', getEntrepriseInfo);

// Routes pour les ressources liées
router.get('/:id/documents', getEntrepriseDocuments);
router.get('/:id/controls', getEntrepriseControls);
router.get('/:id/affiliations', getEntrepriseAffiliations);
router.get('/:id/kpi-history', getEntrepriseKPIHistory);
router.get('/:id/messages', getEntrepriseMessages);
router.get('/:id/reports', getEntrepriseReports);

module.exports = router;
