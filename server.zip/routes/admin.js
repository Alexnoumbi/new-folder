const express = require('express');
const {
    getAdminStats,
    getRecentActivity,
    getPortfolioStats,
    getSecurityAlerts,
    getSecurityStatus,
    createSecurityAlert,
    getComplianceStatus,
    getAuditLogs,
    getSystemInfo
} = require('../controllers/adminController');
const { getPortfolioStats: getPortfolioStatistics } = require('../controllers/portfolioController');
const auth = require('../middleware/auth');

const router = express.Router();

// General admin routes
router.get('/stats', getAdminStats);
router.get('/activity', getRecentActivity);
router.get('/system-info', getSystemInfo);

// Portfolio routes
router.get('/portfolio/stats', getPortfolioStatistics);

// Security routes
router.get('/security/alerts', getSecurityAlerts);
router.get('/security/status', getSecurityStatus);
router.post('/security/alerts', createSecurityAlert);

// Audit routes
router.get('/audit/logs', getAuditLogs);
router.get('/audit/compliance', getComplianceStatus);

module.exports = router;
