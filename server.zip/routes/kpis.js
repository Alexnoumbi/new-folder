const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const kpiController = require('../controllers/kpiController');

// Routes principales des KPIs
router.get('/', kpiController.getKPIs); // Route publique pour récupérer les KPIs
router.post('/', kpiController.createKPI); // Route publique pour créer des KPIs
router.get('/:id', auth, kpiController.getKPI);
router.put('/:id', auth, kpiController.updateKPI);
router.delete('/:id', auth, kpiController.deleteKPI);

// Routes spécifiques aux entreprises
router.get('/enterprise/:enterpriseId', auth, kpiController.getEnterpriseKPIs);
router.post('/:kpiId/submit', auth, kpiController.submitKPIValue);
router.get('/:kpiId/history', auth, kpiController.getKPIHistory);

module.exports = router;