const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const visitController = require('../controllers/visitController');

// Routes de base
router.post('/request', auth, visitController.requestVisit);
router.get('/enterprise/:enterpriseId', auth, visitController.getEnterpriseVisits);

// Routes pour la gestion des visites
router.put('/:id/cancel', auth, visitController.cancelVisit);
router.put('/:id/assign-inspector', auth, visitController.assignInspector);
router.put('/:id/status', auth, visitController.updateVisitStatus);

// Routes de rapports
router.post('/:id/report', auth, visitController.submitVisitReport);
router.get('/:id/report/download', auth, visitController.downloadReport);

module.exports = router;
