const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const documentController = require('../controllers/documentController');

// Routes des documents
router.post('/company/:companyId/upload', auth, documentController.uploadDocument);
router.get('/company/:companyId', auth, documentController.getCompanyDocuments);

module.exports = router;
