const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const { checkRole } = require('../middleware/roles');
const KPI = require('../models/KPI');
const Entreprise = require('../models/Entreprise');

// Get KPI history for an enterprise
router.get('/:id/kpi-history', auth, async (req, res) => {
  try {
    const entreprise = await Entreprise.findById(req.params.id);
    if (!entreprise) {
      return res.status(404).json({ message: 'Entreprise non trouvée' });
    }

    // Ensure user has access to this enterprise
    if (req.user.typeCompte === 'entreprise' && req.user.entreprise.toString() !== req.params.id) {
      return res.status(403).json({ message: 'Accès non autorisé' });
    }

    // Get KPI history for the last 12 months
    const twelveMonthsAgo = new Date();
    twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);

    const kpiHistory = await KPI.aggregate([
      {
        $match: {
          entreprise: entreprise._id,
          date: { $gte: twelveMonthsAgo }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: "$date" },
            month: { $month: "$date" }
          },
          averageScore: { $avg: "$score" }
        }
      },
      {
        $sort: {
          "_id.year": 1,
          "_id.month": 1
        }
      },
      {
        $project: {
          _id: 0,
          date: {
            $dateFromParts: {
              year: "$_id.year",
              month: "$_id.month",
              day: 1
            }
          },
          value: { $round: ["$averageScore", 2] }
        }
      }
    ]);

    res.json(kpiHistory);
  } catch (error) {
    console.error('Error fetching KPI history:', error);
    res.status(500).json({ message: 'Erreur lors de la récupération de l\'historique KPI' });
  }
});

module.exports = router;
