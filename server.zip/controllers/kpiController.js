const KPI = require('../models/KPI');
const mongoose = require('mongoose');

// Récupérer tous les KPIs
exports.getKPIs = async (req, res) => {
    try {
        const kpis = await KPI.find()
            .sort({ createdAt: -1 });

        res.json({
            success: true,
            data: kpis
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des KPIs:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la récupération des KPIs'
        });
    }
};

// Créer un nouveau KPI
exports.createKPI = async (req, res) => {
    try {
        const {
            name,
            description,
            type,
            unit,
            targetValue,
            minValue,
            maxValue,
            frequency,
            enterprise
        } = req.body;

        const kpi = new KPI({
            name,
            description,
            type,
            unit,
            targetValue,
            minValue,
            maxValue,
            frequency,
            enterprise
        });

        await kpi.save();

        res.status(201).json({
            success: true,
            data: kpi
        });
    } catch (error) {
        console.error('Erreur lors de la création du KPI:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la création du KPI',
            error: error.message
        });
    }
};

// Récupérer un KPI spécifique
exports.getKPI = async (req, res) => {
    try {
        const kpi = await KPI.findById(req.params.id);

        if (!kpi) {
            return res.status(404).json({
                success: false,
                message: 'KPI non trouvé'
            });
        }

        res.json({
            success: true,
            data: kpi
        });
    } catch (error) {
        console.error('Erreur lors de la récupération du KPI:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la récupération du KPI'
        });
    }
};

// Mettre à jour un KPI
exports.updateKPI = async (req, res) => {
    try {
        const kpi = await KPI.findByIdAndUpdate(
            req.params.id,
            { ...req.body, updatedBy: req.user._id },
            { new: true, runValidators: true }
        );

        if (!kpi) {
            return res.status(404).json({
                success: false,
                message: 'KPI non trouvé'
            });
        }

        res.json({
            success: true,
            data: kpi
        });
    } catch (error) {
        console.error('Erreur lors de la mise à jour du KPI:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la mise à jour du KPI'
        });
    }
};

// Supprimer un KPI
exports.deleteKPI = async (req, res) => {
    try {
        const kpi = await KPI.findByIdAndDelete(req.params.id);

        if (!kpi) {
            return res.status(404).json({
                success: false,
                message: 'KPI non trouvé'
            });
        }

        res.json({
            success: true,
            message: 'KPI supprimé avec succès'
        });
    } catch (error) {
        console.error('Erreur lors de la suppression du KPI:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la suppression du KPI'
        });
    }
};

// Récupérer les KPIs d'une entreprise
exports.getEnterpriseKPIs = async (req, res) => {
    try {
        const kpis = await KPI.find({ enterprise: req.params.enterpriseId })
            .sort({ createdAt: -1 });

        res.json({
            success: true,
            data: kpis
        });
    } catch (error) {
        console.error('Erreur lors de la récupération des KPIs de l\'entreprise:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la récupération des KPIs de l\'entreprise'
        });
    }
};

// Soumettre une valeur pour un KPI
exports.submitKPIValue = async (req, res) => {
    try {
        const kpi = await KPI.findById(req.params.kpiId);

        if (!kpi) {
            return res.status(404).json({
                success: false,
                message: 'KPI non trouvé'
            });
        }

        const { value, comment } = req.body;

        kpi.history.push({
            value,
            comment,
            submittedBy: req.user._id,
            submittedAt: new Date()
        });

        await kpi.save();

        res.json({
            success: true,
            data: kpi
        });
    } catch (error) {
        console.error('Erreur lors de la soumission de la valeur:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la soumission de la valeur'
        });
    }
};

// Récupérer l'historique d'un KPI
exports.getKPIHistory = async (req, res) => {
    try {
        const kpi = await KPI.findById(req.params.kpiId)
            .populate('history.submittedBy', 'name email');

        if (!kpi) {
            return res.status(404).json({
                success: false,
                message: 'KPI non trouvé'
            });
        }

        res.json({
            success: true,
            data: kpi.history
        });
    } catch (error) {
        console.error('Erreur lors de la récupération de l\'historique:', error);
        res.status(500).json({
            success: false,
            message: 'Erreur lors de la récupération de l\'historique'
        });
    }
};
