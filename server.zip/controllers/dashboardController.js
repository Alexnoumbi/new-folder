const Entreprise = require('../models/Entreprise');
const User = require('../models/User');
const KPI = require('../models/KPI');
const AuditLog = require('../models/AuditLog');

const getDashboardStats = async (req, res) => {
  try {
    // Statistiques de base avec valeurs par défaut
    let stats = {
      totalEntreprises: 0,
      utilisateursActifs: 0,
      kpiValides: 0,
      alertes: 0,
      evolutionEntreprises: [],
      repartitionStatus: [],
      dernieresActivites: []
    };

    // Récupération des statistiques en parallèle pour de meilleures performances
    const [
      totalEntreprises,
      utilisateursActifs,
      kpiValides,
      alertes,
      evolution,
      activites
    ] = await Promise.all([
      Entreprise.countDocuments(),
      User.countDocuments({ 
        derniereConnexion: { 
          $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) 
        }
      }),
      KPI.countDocuments({ statut: 'VALIDATED' }),
      Entreprise.countDocuments({
        $or: [
          { statut: 'critique' },
          { 'kpis.statut': 'OVERDUE' }
        ]
      }),
      Entreprise.aggregate([
        {
          $match: {
            createdAt: { 
              $gte: new Date(Date.now() - 6 * 30 * 24 * 60 * 60 * 1000) 
            }
          }
        },
        {
          $group: {
            _id: {
              year: { $year: '$createdAt' },
              month: { $month: '$createdAt' }
            },
            count: { $sum: 1 }
          }
        },
        {
          $sort: {
            '_id.year': 1,
            '_id.month': 1
          }
        }
      ]),
      AuditLog.find()
        .sort({ timestamp: -1 })
        .limit(10)
        .populate('user', 'nom email')
    ]);

    // Mise à jour des statistiques
    stats.totalEntreprises = totalEntreprises;
    stats.utilisateursActifs = utilisateursActifs;
    stats.kpiValides = kpiValides;
    stats.alertes = alertes;
    stats.evolutionEntreprises = evolution;
    stats.dernieresActivites = activites;

    res.json(stats);
  } catch (error) {
    console.error('Error in getDashboardStats:', error);
    res.status(500).json({ message: 'Erreur lors de la récupération des statistiques' });
  }
};

module.exports = {
  getDashboardStats
};
