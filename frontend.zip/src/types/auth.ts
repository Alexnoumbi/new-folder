export const getToken = (): string | null => {
  return localStorage.getItem('token');
};

export const setToken = (token: string): void => {
  localStorage.setItem('token', token);
};

export const removeToken = (): void => {
  localStorage.removeItem('token');
};

export const isTokenValid = (): boolean => {
  const token = getToken();
  if (!token) return false;
  
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.exp * 1000 > Date.now();
  } catch {
    return false;
  }
};

export interface User {
  _id: string;
  nom: string;
  prenom: string;
  email: string;
  role: 'user' | 'admin' | 'super_admin';
  typeCompte: 'admin' | 'entreprise';
  entrepriseId?: string;
  entrepriseIncomplete?: boolean;
  telephone?: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  nom: string;
  prenom: string;
  email: string;
  password: string;
  telephone?: string;
  typeCompte: 'admin' | 'entreprise';
}

export interface AuthResponse {
  user: User;
  dashboard?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
}
