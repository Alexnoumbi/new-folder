import React from 'react';
import { Route, Routes, Navigate, Outlet } from 'react-router-dom';
import EnterpriseLayout from '../layouts/EnterpriseLayout';
import EnterpriseDashboard from '../pages/Enterprise/EnterpriseDashboard';
import EnterpriseDashboard from '../pages/Enterprise/EnterpriseDashboard';
import EntrepriseOverview from '../pages/Enterprise/EntrepriseOverview';
import DocumentsPage from '../pages/Enterprise/DocumentsPage';
import EntrepriseAffiliations from '../pages/Enterprise/EntrepriseAffiliations';
import KPIHistory from '../pages/Enterprise/KPIHistory';
import ControlsPage from '../pages/Enterprise/Controls';
import DocumentsPage from '../pages/Enterprise/Documents';
import EntrepriseAffiliations from '../pages/Enterprise/Affiliations';
import MessagesPage from '../pages/Enterprise/Messages';
import ProfilePage from '../pages/Enterprise/Profile';
import ReportsPage from '../pages/Enterprise/Reports';
import { UserRole } from '../types/auth';
import KPIHistoryPage from '../pages/Enterprise/KPIHistoryPage';
import MessagesPage from '../pages/Enterprise/MessagesPage';
import ProfilePage from '../pages/Enterprise/ProfilePage';
import ReportsPage from '../pages/Enterprise/ReportsPage';
import PrivateRoute from '../components/PrivateRoute';
        {/* Route par défaut redirige vers dashboard */}
const EnterpriseRoutes: React.FC = () => {
  return (
        {/* Routes du dashboard entreprise */}
      <Route path="/" element={<EnterpriseLayout><Outlet /></EnterpriseLayout>}>
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
        <Route index element={<Navigate to="dashboard" replace />} />

        {/* Route du dashboard (relative) */}
        <Route path="dashboard" element={
        <Route path="kpi-history" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <KPIHistory />
          </PrivateRoute>
        } />

        {/* Autres routes */}
            <EnterpriseDashboard />
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
        } />

        {/* Autres routes (relative paths) */}

        <Route path="controls" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <ControlsPage />
          </PrivateRoute>
        } />

        <Route path="documents" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <DocumentsPage />
          </PrivateRoute>
        } />

        <Route path="affiliations" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <EntrepriseAffiliations />
          </PrivateRoute>
        } />

        <Route path="messages" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <MessagesPage />
          </PrivateRoute>
        } />

        <Route path="profile" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <ProfilePage />
          </PrivateRoute>
        } />

        <Route path="mon-entreprise" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <MonEntreprise />
          </PrivateRoute>
        } />

        <Route path="list" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <Entreprises />
          </PrivateRoute>
        } />

        <Route path="reports" element={
          <PrivateRoute requiredRole={UserRole.ENTERPRISE}>
            <ReportsPage />
          </PrivateRoute>
        } />
