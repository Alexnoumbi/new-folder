import { useEffect } from 'react';
import { useAppSelector, useAppDispatch } from '../store/hooks';
import { RootState } from '../store/store';
import { setUser as setUserAction, clearUser as clearUserAction, selectCurrentUser } from '../store/slices/userSlice';
import type { User } from '../types/user.types';
import { getEntrepriseInfo } from '../services/entrepriseService';

export const useAuth = () => {
  const dispatch = useAppDispatch();
  const user = useAppSelector(selectCurrentUser);
  const loading = useAppSelector((state: RootState) => state.user.loading);
  const error = useAppSelector((state: RootState) => state.user.error);

  useEffect(() => {
    // Si l'utilisateur est connecté et a un type de compte entreprise, charger les informations de l'entreprise
    const loadEnterpriseInfo = async () => {
      if (user?.typeCompte === 'entreprise' && user.entreprise) {
        try {
          const entrepriseInfo = await getEntrepriseInfo();
          dispatch(setUserAction({ ...user, entrepriseDetails: entrepriseInfo } as User));
          // persist updated user with entrepriseDetails
          try { localStorage.setItem('user', JSON.stringify({ ...user, entrepriseDetails: entrepriseInfo })); } catch {}
        } catch (error) {
          console.error('Erreur lors du chargement des informations de l\'entreprise:', error);
        }
      }
    };

    if (user) {
      loadEnterpriseInfo();
    }
  }, [user?.entreprise, user?.typeCompte, dispatch]);

  const setUser = (u: User | null) => {
    if (u) {
      try { localStorage.setItem('user', JSON.stringify(u)); } catch {}
      dispatch(setUserAction(u));
    } else {
      try { localStorage.removeItem('user'); } catch {}
      dispatch(setUserAction(null));
    }
  };

  const clearUser = () => {
    try { localStorage.removeItem('user'); } catch {}
    dispatch(clearUserAction());
  };

  return {
    user,
    loading,
    error,
    isAuthenticated: !!user,
    setUser,
    clearUser,
    dispatch
  };
};
