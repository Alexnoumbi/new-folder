import React, { useEffect, useState } from 'react';
import {
    Box,
    Typography,
    Button,
    TextField,
    CircularProgress,
    Alert,
    Avatar,
    IconButton,
    Divider,
    FormControlLabel,
    Switch,
} from '@mui/material';
import {
    Edit,
    Save,
    Cancel,
    Refresh,
    Person,
    Email,
    Phone,
    LocationOn,
    Business,
    Security,
    Palette,
    Language
} from '@mui/icons-material';
import { getUserById, updateUser } from '../../services/userService';
import type { User, UserUpdateData } from '../../types/user.types';
import ArgonPageHeader from '../../components/Argon/ArgonPageHeader';
import ArgonCard from '../../components/Argon/ArgonCard';
import { useAuth } from '../../hooks/useAuth';

const ProfilePage: React.FC = () => {
    const { user: currentUser } = useAuth();
    const [profile, setProfile] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [editing, setEditing] = useState(false);
    const [saving, setSaving] = useState(false);
    const [formData, setFormData] = useState<UserUpdateData>({
        preferences: {
            darkMode: false,
            language: 'fr'
        }
    });

    const fetchProfile = async () => {
        if (!currentUser?._id) return;
        try {
            setLoading(true);
            const data = await getUserById(currentUser._id);
            setProfile(data);
            setFormData(data);
        } catch (err: any) {
            setError(err.response?.data?.message || 'Erreur lors du chargement du profil');
            console.error('Error loading profile:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchProfile();
    }, [currentUser]);

    const handleSubmit = async () => {
        if (!profile?._id) return;
        try {
            setSaving(true);
            const updatedUser = await updateUser(profile._id, {
                ...formData,
                preferences: {
                    ...profile.preferences,
                    ...formData.preferences
                }
            });
            setProfile(updatedUser);
            setEditing(false);
        } catch (err: any) {
            setError(err.response?.data?.message || 'Erreur lors de la mise à jour du profil');
            console.error('Error updating profile:', err);
        } finally {
            setSaving(false);
        }
    };

    const handleCancel = () => {
        setFormData(profile || {});
        setEditing(false);
    };

    const breadcrumbs = [
        { label: profile?.typeCompte === 'entreprise' ? 'Entreprise' : 'Administration', href: `/${profile?.typeCompte}` },
        { label: 'Profil' }
    ];

    const headerActions = [
        {
            label: editing ? 'Annuler' : 'Modifier',
            icon: editing ? <Cancel /> : <Edit />,
            onClick: editing ? handleCancel : () => setEditing(true),
            variant: editing ? 'outlined' as const : 'contained' as const,
            color: editing ? 'error' as const : 'primary' as const
        },
        ...(editing ? [{
            label: 'Sauvegarder',
            icon: <Save />,
            onClick: handleSubmit,
            variant: 'contained' as const,
            color: 'success' as const,
            loading: saving
        }] : [{
            label: 'Actualiser',
            icon: <Refresh />,
            onClick: fetchProfile,
            variant: 'outlined' as const,
            color: 'primary' as const
        }])
    ];

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" p={3}>
                <CircularProgress />
            </Box>
        );
    }

    if (error) {
        return (
            <Box p={3}>
                <ArgonPageHeader
                    title="Mon Profil"
                    subtitle="Gestion de votre profil utilisateur"
                    breadcrumbs={breadcrumbs}
                    actions={headerActions}
                />
                <Alert severity="error">{error}</Alert>
            </Box>
        );
    }

    return (
        <Box p={3}>
            <ArgonPageHeader
                title="Mon Profil"
                subtitle="Gestion de votre profil utilisateur"
                breadcrumbs={breadcrumbs}
                actions={headerActions}
                onRefresh={fetchProfile}
                loading={loading}
            />

            {profile && (
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' }, gap: 4 }}>
                    <ArgonCard
                        title="Informations Personnelles"
                        value=""
                        icon={<Person />}
                        color="primary"
                    >
                        <Box sx={{ mt: 2 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                                <Avatar
                                    sx={{
                                        width: 80,
                                        height: 80,
                                        bgcolor: 'primary.main',
                                        mr: 3,
                                        fontSize: '2rem'
                                    }}
                                >
                                    {profile.nom.charAt(0)}
                                </Avatar>
                                <Box>
                                    <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                        {profile.nom} {profile.prenom}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        {profile.role}
                                    </Typography>
                                </Box>
                            </Box>

                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                                <TextField
                                    label="Nom"
                                    value={formData.nom || profile.nom}
                                    onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                                    disabled={!editing}
                                    fullWidth
                                />
                                <TextField
                                    label="Prénom"
                                    value={formData.prenom || profile.prenom}
                                    onChange={(e) => setFormData({ ...formData, prenom: e.target.value })}
                                    disabled={!editing}
                                    fullWidth
                                />
                                <TextField
                                    label="Email"
                                    value={formData.email || profile.email}
                                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                    disabled={!editing}
                                    fullWidth
                                    InputProps={{
                                        startAdornment: <Email sx={{ mr: 1, color: 'text.secondary' }} />
                                    }}
                                />
                                <TextField
                                    label="Téléphone"
                                    value={formData.telephone || profile.telephone || ''}
                                    onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                                    disabled={!editing}
                                    fullWidth
                                    InputProps={{
                                        startAdornment: <Phone sx={{ mr: 1, color: 'text.secondary' }} />
                                    }}
                                />
                            </Box>
                        </Box>
                    </ArgonCard>

                    {profile.typeCompte === 'entreprise' && (
                        <ArgonCard
                            title="Informations Entreprise"
                            value=""
                            icon={<Business />}
                            color="info"
                        >
                            <Box sx={{ mt: 2 }}>
                                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                                    <TextField
                                        label="Entreprise"
                                        value={formData.entreprise || profile.entreprise || ''}
                                        onChange={(e) => setFormData({ ...formData, entreprise: e.target.value })}
                                        disabled={!editing}
                                        fullWidth
                                    />
                                </Box>
                            </Box>
                        </ArgonCard>
                    )}

                    <ArgonCard
                        title="Sécurité"
                        value=""
                        icon={<Security />}
                        color="warning"
                    >
                        <Box sx={{ mt: 2 }}>
                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                                <TextField
                                    type="password"
                                    label="Mot de passe actuel"
                                    value={formData.currentPassword || ''}
                                    onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
                                    disabled={!editing}
                                    fullWidth
                                />
                                <TextField
                                    type="password"
                                    label="Nouveau mot de passe"
                                    value={formData.newPassword || ''}
                                    onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
                                    disabled={!editing}
                                    fullWidth
                                />
                            </Box>
                        </Box>
                    </ArgonCard>

                    <ArgonCard
                        title="Préférences"
                        value=""
                        icon={<Palette />}
                        color="info"
                    >
                        <Box sx={{ mt: 2 }}>
                            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                                <FormControlLabel
                                    control={
                                        <Switch
                                            checked={formData.preferences?.darkMode || false}
                                            onChange={(e) => setFormData({
                                                ...formData,
                                                preferences: {
                                                    ...formData.preferences,
                                                    darkMode: e.target.checked
                                                }
                                            })}
                                            disabled={!editing}
                                        />
                                    }
                                    label="Mode sombre"
                                />
                                <TextField
                                    select
                                    label="Langue"
                                    value={formData.preferences?.language || 'fr'}
                                    onChange={(e) => setFormData({
                                        ...formData,
                                        preferences: {
                                            ...formData.preferences,
                                            language: e.target.value
                                        }
                                    })}
                                    disabled={!editing}
                                    fullWidth
                                    SelectProps={{
                                        native: true
                                    }}
                                    InputProps={{
                                        startAdornment: <Language sx={{ mr: 1, color: 'text.secondary' }} />
                                    }}
                                >
                                    <option value="fr">Français</option>
                                    <option value="en">English</option>
                                </TextField>
                            </Box>
                        </Box>
                    </ArgonCard>
                </Box>
            )}
        </Box>
    );
};

export default ProfilePage;
