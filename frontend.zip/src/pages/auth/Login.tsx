import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  TextField,
  Button,
  Typography,
  Alert,
  CircularProgress,
  Box,
} from '@mui/material';
import { login } from '../../services/authService';
import { useAuth } from '../../hooks/useAuth';
import type { User } from '../../types/user.types';
import './Auth.css';

const Login = () => {
  const navigate = useNavigate();
  const { setUser } = useAuth();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setLoading(true);

    const { email, password } = formData;

    try {
      const response = await login({ email, password });

      // Map auth response to User type
      const user: User = {
        ...response.user,
        status: 'active' // Default status since response.user doesn't have status
      };

      setUser(user);

      const isAdmin = user.role === 'admin' || user.role === 'super_admin' || user.typeCompte === 'admin';
      if (isAdmin) {
        navigate('/admin/dashboard');
      } else {
        navigate('/enterprise/dashboard');
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-form-container">
        <Typography className="auth-title">
          Connexion
        </Typography>
        <Typography className="auth-subtitle">
          Entrez vos identifiants pour accéder à votre compte
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <Box component="form" onSubmit={handleSubmit}>
          <label className="auth-input-label" htmlFor="email">
            Email*
          </label>
          <TextField
            className="auth-input"
            required
            fullWidth
            id="email"
            name="email"
            autoComplete="email"
            placeholder="votre@email.com"
            autoFocus
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />

          <label className="auth-input-label" htmlFor="password">
            Mot de passe*
          </label>
          <TextField
            className="auth-input"
            required
            fullWidth
            name="password"
            type="password"
            id="password"
            autoComplete="current-password"
            placeholder="Votre mot de passe"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          />

          <Button
            type="submit"
            disabled={loading}
            className="auth-button"
          >
            {loading ? <CircularProgress size={24} /> : 'Se connecter'}
          </Button>

          <Button
            component={Link}
            to="/register"
            className="auth-link-button"
          >
            Créer un compte
          </Button>
        </Box>
      </div>
    </div>
  );
};

export default Login;