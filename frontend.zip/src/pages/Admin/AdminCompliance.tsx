import React, { useEffect, useState } from 'react';
import {
    Box,
    Typography,
    CircularProgress,
    Alert,
    Button,
    Chip,
    LinearProgress,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
} from '@mui/material';
import {
    CheckCircle,
    Warning,
    Error,
    Refresh as RefreshIcon,
    Assessment as AssessmentIcon
} from '@mui/icons-material';
import { getComplianceStatus } from '../../services/complianceService';
import { ComplianceStatus } from '../../types/compliance.types';
import ArgonPageHeader from '../../components/Argon/ArgonPageHeader';

const AdminCompliance: React.FC = () => {
    const [compliance, setCompliance] = useState<ComplianceStatus | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchComplianceStatus = async () => {
        try {
            setLoading(true);
            setError(null);
            const data = await getComplianceStatus();
            setCompliance(data);
        } catch (err: any) {
            setError(err.response?.data?.message || 'Erreur lors du chargement du statut de conformité');
            console.error('Compliance status loading error:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        // Vérifier la connectivité du serveur avant de charger les données
        fetch('http://localhost:5000/api/health')
            .then(response => response.json())
            .then(data => {
                console.log('✅ Serveur accessible:', data);
                fetchComplianceStatus();
            })
            .catch(error => {
                console.error('❌ Serveur inaccessible:', error);
                setError('Serveur inaccessible. Vérifiez que le serveur backend est démarré sur le port 5000.');
                setLoading(false);
            });
    }, []);

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
                <CircularProgress />
            </Box>
        );
    }

    const getStatusColor = (score: number): 'success' | 'warning' | 'error' => {
        if (score >= 90) return 'success';
        if (score >= 70) return 'warning';
        return 'error';
    };

    const getStatusIcon = (score: number) => {
        if (score >= 90) return <CheckCircle color="success" />;
        if (score >= 70) return <Warning color="warning" />;
        return <Error color="error" />;
    };

    const breadcrumbs = [
        { label: 'Administration', href: '/admin' },
        { label: 'Conformité' }
    ];

    const headerActions = [
        {
            label: 'Actualiser',
            icon: <RefreshIcon />,
            onClick: fetchComplianceStatus,
            variant: 'outlined' as const,
            color: 'primary' as const
        },
        {
            label: 'Rapport',
            icon: <AssessmentIcon />,
            onClick: () => console.log('Générer rapport conformité'),
            variant: 'contained' as const,
            color: 'primary' as const
        }
    ];

    return (
        <Box p={3}>
            <ArgonPageHeader
                title="Conformité"
                subtitle="Gestion de la conformité réglementaire"
                breadcrumbs={breadcrumbs}
                actions={headerActions}
                onRefresh={fetchComplianceStatus}
                loading={loading}
            />

            {error && (
                <Alert
                    severity="error"
                    action={
                        <Button color="inherit" size="small" onClick={fetchComplianceStatus}>
                            Réessayer
                        </Button>
                    }
                    sx={{ mb: 3 }}
                >
                    {error}
                </Alert>
            )}

            {loading ? (
                <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
                    <CircularProgress />
                </Box>
            ) : compliance ? (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                        <Box sx={{ flex: { xs: '1 1 100%', md: '0 1 calc(33.333% - 16px)' }, minWidth: 0 }}>
                            <Paper sx={{ p: 3 }}>
                                <Typography variant="h6" gutterBottom>Score Global</Typography>
                                <Box display="flex" alignItems="center" justifyContent="space-between">
                                    <Typography variant="h3" color={`${getStatusColor(compliance.overallScore)}.main`}>
                                        {compliance.overallScore}%
                                    </Typography>
                                    {getStatusIcon(compliance.overallScore)}
                                </Box>
                                <LinearProgress
                                    variant="determinate"
                                    value={compliance.overallScore}
                                    color={getStatusColor(compliance.overallScore)}
                                    sx={{ mt: 2 }}
                                />
                            </Paper>
                        </Box>

                        <Box sx={{ flex: { xs: '1 1 100%', md: '0 1 calc(66.666% - 16px)' }, minWidth: 0 }}>
                            <Paper sx={{ p: 3, height: '100%' }}>
                                <Typography variant="h6" gutterBottom>Résumé des Contrôles</Typography>
                                <Box sx={{
                                    display: 'flex',
                                    flexWrap: 'wrap',
                                    gap: 2,
                                    '& > *': { flex: { xs: '1 1 100%', sm: '1 1 calc(33.333% - 16px)' } }
                                }}>
                                    <Box textAlign="center">
                                        <Typography variant="h4" color="success.main">
                                            {compliance.passedControls}
                                        </Typography>
                                        <Typography variant="body2">Validés</Typography>
                                    </Box>
                                    <Box textAlign="center">
                                        <Typography variant="h4" color="warning.main">
                                            {compliance.pendingControls}
                                        </Typography>
                                        <Typography variant="body2">En attente</Typography>
                                    </Box>
                                    <Box textAlign="center">
                                        <Typography variant="h4" color="error.main">
                                            {compliance.failedControls}
                                        </Typography>
                                        <Typography variant="body2">Échoués</Typography>
                                    </Box>
                                </Box>
                            </Paper>
                        </Box>
                    </Box>

                    <Box>
                        <TableContainer component={Paper}>
                            <Table>
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Catégorie</TableCell>
                                        <TableCell>Score</TableCell>
                                        <TableCell>Contrôles Validés</TableCell>
                                        <TableCell>Contrôles Totaux</TableCell>
                                        <TableCell>Dernière Évaluation</TableCell>
                                        <TableCell>Statut</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {compliance.categories && compliance.categories.length > 0 ? (
                                        compliance.categories.map((category) => (
                                            <TableRow key={category.categoryId}>
                                                <TableCell>{category.name}</TableCell>
                                                <TableCell>
                                                    <Box display="flex" alignItems="center">
                                                        <Typography variant="body2" mr={1}>
                                                            {category.score}%
                                                        </Typography>
                                                        {getStatusIcon(category.score)}
                                                    </Box>
                                                </TableCell>
                                                <TableCell>{category.items.filter(item => item.status === 'compliant').length}</TableCell>
                                                <TableCell>{category.items.length}</TableCell>
                                                <TableCell>
                                                    {category.lastAssessment ? new Date(category.lastAssessment).toLocaleDateString() : 'N/A'}
                                                </TableCell>
                                                <TableCell>
                                                    <Chip
                                                        label={category.status === 'compliant' ? 'Conforme' :
                                                               category.status === 'partial' ? 'À améliorer' : 'Non conforme'}
                                                        color={category.status === 'compliant' ? 'success' :
                                                               category.status === 'partial' ? 'warning' : 'error'}
                                                        size="small"
                                                    />
                                                </TableCell>
                                            </TableRow>
                                        ))
                                    ) : (
                                        <TableRow>
                                            <TableCell colSpan={6} align="center">
                                                <Typography color="text.secondary">
                                                    Aucune catégorie de conformité disponible
                                                </Typography>
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Box>
                </Box>
            ) : (
                <Alert severity="info" sx={{ mt: 3 }}>
                    Aucune donnée de conformité disponible. Cliquez sur actualiser pour charger les données.
                </Alert>
            )}
        </Box>
    );
};

export default AdminCompliance;
