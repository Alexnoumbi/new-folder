import React from 'react';
import { useLocation } from 'react-router-dom';

interface PrivateRouteProps {
  children: React.ReactNode;
}

// Version simplifiée qui rend toujours les enfants pour le dashboard entreprise
const PrivateRoute: React.FC<PrivateRouteProps> = ({ children }) => {
  const location = useLocation();

  // Debug log
  console.log('PrivateRoute - Current path:', location.pathname);

  // Toujours rendre les enfants sans vérification
  return <>{children}</>;
};

export default PrivateRoute;
