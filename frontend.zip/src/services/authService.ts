import axios from 'axios';
import { LoginCredentials, RegisterData, AuthResponse } from '../types/auth.types';

const API_URL = 'http://localhost:5000/api';

export const login = async ({ email, password }: LoginCredentials): Promise<AuthResponse> => {
  try {
    // Stocker les informations d'authentification pour les autres appels API
    localStorage.setItem('userEmail', email);
    localStorage.setItem('userPassword', password);

    const response = await axios.post(`${API_URL}/auth/login`, { email, password });
    const { user } = response.data;

    // Stocker l'utilisateur localement
    localStorage.setItem('user', JSON.stringify(user));

    return response.data;
  } catch (error) {
    console.error('Erreur de connexion:', error);
    throw error;
  }
};

export const register = async (data: RegisterData): Promise<AuthResponse> => {
  try {
    const response = await axios.post(`${API_URL}/auth/register`, data);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de l\'inscription:', error);
    throw error;
  }
};

export const logout = async (): Promise<void> => {
  // Nettoyer les informations stockées
  localStorage.removeItem('userEmail');
  localStorage.removeItem('userPassword');
  localStorage.removeItem('user');
  return;
};

// Version simplifiée qui retourne toujours l'utilisateur stocké
export const getCurrentUser = () => {
  try {
    const storedUser = localStorage.getItem('user');
    return storedUser ? JSON.parse(storedUser) : null;
  } catch (e) {
    return null;
  }
};

// Simple getter pour les tokens - pour compatibilité avec AuthDebug
export const getStoredToken = (): string | null => {
  const user = getCurrentUser();
  return user?.token || null;
};
