import api from './api';
import { AdminStats } from '../types/admin.types';

export const getDashboardStats = async (): Promise<AdminStats> => {
    try {
        // Utilisation du bon endpoint
        const response = await api.get('/admin/stats');
        console.log('Response from API:', response); // Debug log
        return response.data.data;
    } catch (error: any) {
        console.error('Dashboard error:', error);
        throw error;
    }
};
