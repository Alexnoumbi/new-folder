import axios from 'axios';

const api = axios.create({
    baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
    headers: {
        'Content-Type': 'application/json'
    }
});

// Ajouter email et mot de passe à toutes les requêtes
api.interceptors.request.use(
    config => {
        const email = localStorage.getItem('userEmail');
        const password = localStorage.getItem('userPassword');

        if (email) {
            config.headers['x-user-email'] = email;
        }
        if (password) {
            config.headers['x-user-password'] = password;
        }

        return config;
    },
    error => {
        return Promise.reject(error);
    }
);

// Gérer les erreurs de réponse
api.interceptors.response.use(
    response => response,
    error => {
        // Ne pas rediriger, juste logger l'erreur
        console.error('API Error:', error);
        return Promise.reject(error);
    }
);

export default api;