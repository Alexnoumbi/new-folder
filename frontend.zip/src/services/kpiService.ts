import api from './api';
import { KPI, KPIFormData } from '../types/kpi.types';

const getAuthHeader = () => {
    const token = localStorage.getItem('token');
    return {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
};

export const getKPIs = async (): Promise<KPI[]> => {
    try {
        const response = await api.get('/kpis'); // Retrait de getAuthHeader() car la route est publique
        return response.data?.data || [];
    } catch (error) {
        console.error('Erreur lors de la récupération des KPIs:', error);
        throw error;
    }
};

// Les autres méthodes gardent l'authentification
export const createKPI = async (data: KPIFormData): Promise<KPI> => {
    try {
        const response = await api.post('/kpis', data); // Retrait de getAuthHeader()
        return response.data?.data;
    } catch (error) {
        console.error('Erreur lors de la création du KPI:', error);
        throw error;
    }
};

export const updateKPI = async (id: string, data: Partial<KPIFormData>): Promise<KPI> => {
    try {
        const response = await api.put(`/kpis/${id}`, data, getAuthHeader());
        return response.data?.data;
    } catch (error) {
        console.error('Erreur lors de la mise à jour du KPI:', error);
        throw error;
    }
};

export const deleteKPI = async (id: string): Promise<void> => {
    try {
        await api.delete(`/kpis/${id}`, getAuthHeader());
    } catch (error) {
        console.error('Erreur lors de la suppression du KPI:', error);
        throw error;
    }
};

export const getKPIHistory = async (kpiId: string): Promise<any[]> => {
    try {
        const response = await api.get(`/kpis/${kpiId}/history`, getAuthHeader());
        return response.data?.data || [];
    } catch (error) {
        console.error('Erreur lors de la récupération de l\'historique:', error);
        throw error;
    }
};

export const submitKPIValue = async (kpiId: string, data: { value: number; comment?: string }): Promise<any> => {
    try {
        const response = await api.post(`/kpis/${kpiId}/submit`, data, getAuthHeader());
        return response.data?.data;
    } catch (error) {
        console.error('Erreur lors de la soumission de la valeur:', error);
        throw error;
    }
};

export const getEnterpriseKPIs = async (enterpriseId: string): Promise<KPI[]> => {
    try {
        const response = await api.get(`/kpis/enterprise/${enterpriseId}`, getAuthHeader());
        return response.data?.data || [];
    } catch (error) {
        console.error('Erreur lors de la récupération des KPIs de l\'entreprise:', error);
        throw error;
    }
};
